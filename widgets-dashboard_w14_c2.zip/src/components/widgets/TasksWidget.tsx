const TasksWidget = () => {
  return <div>TasksWidget</div>;
};

export default TasksWidget;
